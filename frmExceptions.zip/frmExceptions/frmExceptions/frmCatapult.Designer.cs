﻿namespace frmExceptions
{
    partial class frmCatapult
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCatapult));
            btnSetTarget = new Button();
            btnLaunch = new Button();
            lbStatus = new ListBox();
            lblMessage = new Label();
            lblTitle = new Label();
            SuspendLayout();
            // 
            // btnSetTarget
            // 
            btnSetTarget.BackColor = SystemColors.ButtonHighlight;
            btnSetTarget.Font = new Font("Showcard Gothic", 15F);
            btnSetTarget.Location = new Point(63, 71);
            btnSetTarget.Name = "btnSetTarget";
            btnSetTarget.Size = new Size(160, 43);
            btnSetTarget.TabIndex = 0;
            btnSetTarget.Text = "Set Target";
            btnSetTarget.UseVisualStyleBackColor = false;
            btnSetTarget.Click += btnSetTarget_Click;
            // 
            // btnLaunch
            // 
            btnLaunch.BackColor = SystemColors.ButtonHighlight;
            btnLaunch.Enabled = false;
            btnLaunch.Font = new Font("Showcard Gothic", 20F);
            btnLaunch.Location = new Point(231, 71);
            btnLaunch.Name = "btnLaunch";
            btnLaunch.Size = new Size(151, 43);
            btnLaunch.TabIndex = 1;
            btnLaunch.Text = "Launch Watermelons";
            btnLaunch.UseVisualStyleBackColor = false;
            btnLaunch.Click += btnLaunch_Click;
            // 
            // lbStatus
            // 
            lbStatus.FormattingEnabled = true;
            lbStatus.Location = new Point(63, 120);
            lbStatus.Name = "lbStatus";
            lbStatus.Size = new Size(675, 304);
            lbStatus.TabIndex = 2;
            // 
            // lblMessage
            // 
            lblMessage.AutoSize = true;
            lblMessage.Location = new Point(370, 53);
            lblMessage.Name = "lblMessage";
            lblMessage.Size = new Size(0, 15);
            lblMessage.TabIndex = 3;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.BackColor = SystemColors.ButtonHighlight;
            lblTitle.Font = new Font("Showcard Gothic", 30F, FontStyle.Bold);
            lblTitle.Location = new Point(63, 18);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(733, 50);
            lblTitle.TabIndex = 4;
            lblTitle.Text = "Launch watermelons at trolls!";
            // 
            // frmCatapult
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(800, 450);
            Controls.Add(lblTitle);
            Controls.Add(lblMessage);
            Controls.Add(lbStatus);
            Controls.Add(btnLaunch);
            Controls.Add(btnSetTarget);
            Name = "frmCatapult";
            Text = "Catapult Launcher";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSetTarget;
        private Button btnLaunch;
        private ListBox lbStatus;
        private Label lblMessage;
        private Label lblTitle;
    }
}