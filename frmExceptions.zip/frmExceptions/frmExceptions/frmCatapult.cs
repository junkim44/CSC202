﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace frmExceptions
{
    public partial class frmCatapult : Form
    {
        // having it outside frmCatapult makes it more global variable
        // create a random object from the Random Class so we can generate a random number
        Random random = new Random();
        // Variable to keep track of what the current target is
        int iTargetDistance = 0;
        public frmCatapult()
        {
            InitializeComponent();
        }
        private void btnSetTarget_Click(object sender, EventArgs e)
        {
            // get a random distance between the values you specify here -
            // inclusive of the lower number and exclusive of the higher number
            iTargetDistance = random.Next(40, 51);
            
            // clear out old launch info
            lbStatus.Items.Clear();

            // add target to the listbox
            lbStatus.Items.Add($"Target distance: Troll is {iTargetDistance} ft away.");

            // enable the Launch button now that a Target has been set
            btnLaunch.Enabled = true;
        }
        private void btnLaunch_Click(object sender, EventArgs e)
        {
            // just in case the launch distance had not been set, show an error message
            if (iTargetDistance == 0)
            {
                // show a message on the label
                lblMessage.Text = "Please set a target.";
                // leave this method
                return; 
            }

            // set the random number to the different range
            int iLaunchDistance = random.Next(30, 61);
            // variable for how much the target missed by
            int iMissedDistance = 0;
            // add target to the listbox
            lbStatus.Items.Add($"Launch distance: {iLaunchDistance} ft");
            // if launch distance is the same as target distance, target was hit
            if( iLaunchDistance == iTargetDistance)
            {
                // Message to show the target was hit
                lbStatus.Items.Add($"Success! Troll hit with a watermelon!");
            } 
            // else if launch missed the target, by how much?
            else
            {
                // If target missed, set missed distance by subtracting target distance from launch distance.
                iMissedDistance = iLaunchDistance - iTargetDistance;
                // if the missed distance is equal to negative, it means the launch was too short
                if (iMissedDistance < 0)
                {
                    // message to show how much the launch missed by, with too short, converting negative number with Math.Abs
                    lbStatus.Items.Add($"Miss! {Math.Abs(iMissedDistance)} ft shy of hitting the Troll!");
                }
                else
                {
                    // message to show how much further you launched than the target distance
                    lbStatus.Items.Add($"Miss! Launched {iMissedDistance} ft too far from the Troll!");
                }
            }
        }
    }
}
