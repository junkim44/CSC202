namespace frmExceptions
{
    public partial class frmExceptions : Form
    {
        public frmExceptions()
        {
            InitializeComponent();
        }

        private async void btnGenEx_Click(object sender, EventArgs e)
        {
            // counter variable for the loop
            int counter = 0;

            // try to run the code, but include a catch statement in case there is an exception
            while (counter < 5)
            {
                // while loop that throws a new exception each time it runs
                try
                {
                    if (counter == 0)
                    {
                        throw new IndexOutOfRangeException("Index was outside the bounds of the array.");
                    }
                    else if (counter == 1)
                    {
                        throw new NullReferenceException("Object reference not set to an instance of an object");
                    }
                    else if (counter == 2)
                    {
                        throw new DivideByZeroException("Attempted to divide by zero");
                    }
                    else if (counter == 3)
                    {
                        throw new FormatException("Input string was not in the correct format.");
                    }
                    else if (counter == 4) {
                        throw new FileFormatException("File format was not correctd");
                    }
                }
                catch (Exception ex)
                {
                    // add the exception details to the listbox instead of stopping the message
                    lbEx.Items.Add($"{DateTime.Now}: {ex.GetType().Name}: {ex.Message}");   // DateTime.Now gives date and time now
                }

                // catch that error that was thrown and do something about it

                // In order to avoid infinite loop, increase the value of counter before doing anything else
                counter++;

                // wait 1000 miliseconds = 1 second between instances of this code running
                await Task.Delay(1000);
            }
        }
    }
}
