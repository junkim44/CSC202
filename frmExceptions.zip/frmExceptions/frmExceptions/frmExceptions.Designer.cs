﻿namespace frmExceptions
{
    partial class frmExceptions
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnGenEx = new Button();
            lbEx = new ListBox();
            SuspendLayout();
            // 
            // btnGenEx
            // 
            btnGenEx.Location = new Point(50, 62);
            btnGenEx.Name = "btnGenEx";
            btnGenEx.Size = new Size(103, 27);
            btnGenEx.TabIndex = 0;
            btnGenEx.Text = "Generate Exceptions";
            btnGenEx.UseVisualStyleBackColor = true;
            btnGenEx.Click += btnGenEx_Click;
            // 
            // lbEx
            // 
            lbEx.FormattingEnabled = true;
            lbEx.Location = new Point(50, 112);
            lbEx.Name = "lbEx";
            lbEx.ScrollAlwaysVisible = true;
            lbEx.Size = new Size(694, 304);
            lbEx.TabIndex = 1;
            // 
            // frmExceptions
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lbEx);
            Controls.Add(btnGenEx);
            Name = "frmExceptions";
            Text = "Fun with Exceptions";
            ResumeLayout(false);
        }

        #endregion

        private Button btnGenEx;
        private ListBox lbEx;
    }
}
