﻿namespace AmortizationCalculator
{
    partial class frmMortSchedule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitleMort = new Label();
            lbMortSchedule = new ListBox();
            btnExport = new Button();
            btnBack = new Button();
            lbLoanStats = new ListBox();
            SuspendLayout();
            // 
            // lblTitleMort
            // 
            lblTitleMort.AutoSize = true;
            lblTitleMort.Font = new Font("Segoe UI", 20F);
            lblTitleMort.Location = new Point(254, 25);
            lblTitleMort.Name = "lblTitleMort";
            lblTitleMort.Size = new Size(249, 37);
            lblTitleMort.TabIndex = 0;
            lblTitleMort.Text = "Mortgage Schedule";
            // 
            // lbMortSchedule
            // 
            lbMortSchedule.FormattingEnabled = true;
            lbMortSchedule.Location = new Point(311, 91);
            lbMortSchedule.Name = "lbMortSchedule";
            lbMortSchedule.Size = new Size(461, 289);
            lbMortSchedule.TabIndex = 1;
            // 
            // btnExport
            // 
            btnExport.AutoSize = true;
            btnExport.Font = new Font("Segoe UI", 12F);
            btnExport.Location = new Point(29, 398);
            btnExport.Name = "btnExport";
            btnExport.Size = new Size(120, 31);
            btnExport.TabIndex = 3;
            btnExport.Text = "Export to File";
            btnExport.UseVisualStyleBackColor = true;
            btnExport.Click += btnExport_Click;
            // 
            // btnBack
            // 
            btnBack.AutoSize = true;
            btnBack.Font = new Font("Segoe UI", 12F);
            btnBack.Location = new Point(697, 398);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(75, 31);
            btnBack.TabIndex = 4;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // lbLoanStats
            // 
            lbLoanStats.Font = new Font("Segoe UI", 11F);
            lbLoanStats.FormattingEnabled = true;
            lbLoanStats.Location = new Point(29, 91);
            lbLoanStats.Name = "lbLoanStats";
            lbLoanStats.Size = new Size(250, 284);
            lbLoanStats.TabIndex = 5;
            // 
            // frmMortSchedule
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lbLoanStats);
            Controls.Add(btnBack);
            Controls.Add(btnExport);
            Controls.Add(lbMortSchedule);
            Controls.Add(lblTitleMort);
            Name = "frmMortSchedule";
            Text = "frmMortSchedule";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitleMort;
        private ListBox lbMortSchedule;
        private Button btnSaveMort;
        private Button btnExport;
        private Button btnBack;
        private ListBox lbLoanStats;
    }
}