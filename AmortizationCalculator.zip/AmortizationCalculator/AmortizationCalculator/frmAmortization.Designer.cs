﻿namespace AmortizationCalculator
{
    partial class frmAmortization
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitle = new Label();
            btnCalcMort = new Button();
            lblInstruction = new Label();
            txtPrincipal = new TextBox();
            lblMortAmount = new Label();
            pnlMortgage = new Panel();
            btnLoad = new Button();
            lblException = new Label();
            lblExInst = new Label();
            txtExtraPay = new TextBox();
            lblMortExPay = new Label();
            txtInterest = new TextBox();
            lblIntRate = new Label();
            txtTermYear = new TextBox();
            lblMortTerm = new Label();
            lblInstruction2 = new Label();
            pnlMortgage.SuspendLayout();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 20F);
            lblTitle.Location = new Point(197, 31);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(352, 37);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "UAT Amortization Calculator";
            // 
            // btnCalcMort
            // 
            btnCalcMort.AutoSize = true;
            btnCalcMort.Font = new Font("Segoe UI", 12F);
            btnCalcMort.Location = new Point(318, 239);
            btnCalcMort.Name = "btnCalcMort";
            btnCalcMort.Size = new Size(194, 31);
            btnCalcMort.TabIndex = 1;
            btnCalcMort.Text = "Calculate Mortgage";
            btnCalcMort.UseVisualStyleBackColor = true;
            btnCalcMort.Click += btnCalcMort_Click;
            // 
            // lblInstruction
            // 
            lblInstruction.AutoSize = true;
            lblInstruction.Location = new Point(30, 93);
            lblInstruction.Name = "lblInstruction";
            lblInstruction.Size = new Size(666, 15);
            lblInstruction.TabIndex = 3;
            lblInstruction.Text = "Welcome to UAT Amortization Calculator. Please select from the following options to calculate the amortization of your loan!";
            // 
            // txtPrincipal
            // 
            txtPrincipal.Location = new Point(328, 17);
            txtPrincipal.Name = "txtPrincipal";
            txtPrincipal.Size = new Size(174, 23);
            txtPrincipal.TabIndex = 4;
            // 
            // lblMortAmount
            // 
            lblMortAmount.AutoSize = true;
            lblMortAmount.Font = new Font("Segoe UI", 12F);
            lblMortAmount.Location = new Point(149, 15);
            lblMortAmount.Name = "lblMortAmount";
            lblMortAmount.Size = new Size(136, 21);
            lblMortAmount.TabIndex = 5;
            lblMortAmount.Text = "Mortage Principal:";
            // 
            // pnlMortgage
            // 
            pnlMortgage.Controls.Add(btnLoad);
            pnlMortgage.Controls.Add(lblException);
            pnlMortgage.Controls.Add(lblExInst);
            pnlMortgage.Controls.Add(txtExtraPay);
            pnlMortgage.Controls.Add(lblMortExPay);
            pnlMortgage.Controls.Add(txtInterest);
            pnlMortgage.Controls.Add(lblIntRate);
            pnlMortgage.Controls.Add(txtTermYear);
            pnlMortgage.Controls.Add(lblMortTerm);
            pnlMortgage.Controls.Add(lblMortAmount);
            pnlMortgage.Controls.Add(txtPrincipal);
            pnlMortgage.Controls.Add(btnCalcMort);
            pnlMortgage.Location = new Point(31, 149);
            pnlMortgage.Name = "pnlMortgage";
            pnlMortgage.Size = new Size(665, 289);
            pnlMortgage.TabIndex = 6;
            // 
            // btnLoad
            // 
            btnLoad.AutoSize = true;
            btnLoad.Font = new Font("Segoe UI", 12F);
            btnLoad.Location = new Point(141, 239);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(171, 31);
            btnLoad.TabIndex = 15;
            btnLoad.Text = "Load Previous Inquiry";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // lblException
            // 
            lblException.AutoSize = true;
            lblException.Location = new Point(149, 185);
            lblException.Name = "lblException";
            lblException.Size = new Size(0, 15);
            lblException.TabIndex = 13;
            // 
            // lblExInst
            // 
            lblExInst.AutoSize = true;
            lblExInst.Location = new Point(149, 157);
            lblExInst.Name = "lblExInst";
            lblExInst.Size = new Size(278, 15);
            lblExInst.TabIndex = 12;
            lblExInst.Text = "**Extra payment will go towards principal balance**";
            // 
            // txtExtraPay
            // 
            txtExtraPay.Location = new Point(328, 131);
            txtExtraPay.Name = "txtExtraPay";
            txtExtraPay.Size = new Size(174, 23);
            txtExtraPay.TabIndex = 11;
            // 
            // lblMortExPay
            // 
            lblMortExPay.AutoSize = true;
            lblMortExPay.Font = new Font("Segoe UI", 12F);
            lblMortExPay.Location = new Point(149, 129);
            lblMortExPay.Name = "lblMortExPay";
            lblMortExPay.Size = new Size(173, 21);
            lblMortExPay.TabIndex = 10;
            lblMortExPay.Text = "Extra Monthly Payment:";
            // 
            // txtInterest
            // 
            txtInterest.Location = new Point(328, 89);
            txtInterest.Name = "txtInterest";
            txtInterest.Size = new Size(174, 23);
            txtInterest.TabIndex = 9;
            // 
            // lblIntRate
            // 
            lblIntRate.AutoSize = true;
            lblIntRate.Font = new Font("Segoe UI", 12F);
            lblIntRate.Location = new Point(149, 87);
            lblIntRate.Name = "lblIntRate";
            lblIntRate.Size = new Size(123, 21);
            lblIntRate.TabIndex = 8;
            lblIntRate.Text = "Interest Rate(%):";
            // 
            // txtTermYear
            // 
            txtTermYear.Location = new Point(328, 53);
            txtTermYear.Name = "txtTermYear";
            txtTermYear.Size = new Size(174, 23);
            txtTermYear.TabIndex = 7;
            // 
            // lblMortTerm
            // 
            lblMortTerm.AutoSize = true;
            lblMortTerm.Font = new Font("Segoe UI", 12F);
            lblMortTerm.Location = new Point(149, 53);
            lblMortTerm.Name = "lblMortTerm";
            lblMortTerm.Size = new Size(163, 21);
            lblMortTerm.TabIndex = 6;
            lblMortTerm.Text = "Mortgage Term (year):";
            // 
            // lblInstruction2
            // 
            lblInstruction2.AutoSize = true;
            lblInstruction2.Location = new Point(197, 119);
            lblInstruction2.Name = "lblInstruction2";
            lblInstruction2.Size = new Size(309, 15);
            lblInstruction2.TabIndex = 8;
            lblInstruction2.Text = "** This app will not include escrows into the calculation**";
            // 
            // frmAmortization
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(729, 450);
            Controls.Add(lblInstruction2);
            Controls.Add(pnlMortgage);
            Controls.Add(lblInstruction);
            Controls.Add(lblTitle);
            Name = "frmAmortization";
            Text = "Form1";
            pnlMortgage.ResumeLayout(false);
            pnlMortgage.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private Button btnCalcMort;
        private Label lblInstruction;
        private TextBox txtPrincipal;
        private Label lblMortAmount;
        private Panel pnlMortgage;
        private TextBox txtExtraPay;
        private Label lblMortExPay;
        private TextBox txtInterest;
        private Label lblIntRate;
        private TextBox txtTermYear;
        private Label lblMortTerm;
        private Label lblExInst;
        private Label lblInstruction2;
        private Label lblException;
        private Button btnLoad;
    }
}
