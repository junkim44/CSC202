﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Windows.Forms;

namespace AmortizationCalculator
{
    public partial class frmMortSchedule : Form
    {
        // Creating list to export into a json file later
        List<string> loanDetails = new List<string>();
        public frmMortSchedule(List<string> scheduleData, double mPrincipal, int mTermMonth, double mInterest, double mMonthlyPay, double mTotalPaid, double mTotalInterest, string[] input)
        {
            InitializeComponent();
            
            // Display loanData on lbLoanStats, doing it this way for better UX
            lbLoanStats.Items.Add($"Principal: ${mPrincipal}");
            lbLoanStats.Items.Add($"Interest: {mInterest}%");
            lbLoanStats.Items.Add($"Original Loan Term: {input[2]} months");
            lbLoanStats.Items.Add($"Months to pay off: {mTermMonth} months");
            lbLoanStats.Items.Add($"Monthly Payment: ${Math.Round(mMonthlyPay,2)}");
            lbLoanStats.Items.Add($"Extra Monthly Payment: ${input[4]}");
            lbLoanStats.Items.Add($"Total Paid into Loan: ${Math.Round(mTotalPaid,2)}");
            lbLoanStats.Items.Add($"Total Paid to Interest: ${Math.Round(mTotalInterest,2)}");
            // Display scheduleData on lbMortSchedule
            foreach (string item in scheduleData)
            {
                lbMortSchedule.Items.Add(item);
            }
        }
        public frmMortSchedule(frmAmortization frmAmortizationObj)
        {
            InitializeComponent();
        }
        private void btnBack_Click(object sender, EventArgs e) // Option for user to go back to starting page
        {
            // creating instance of new form for frmAmortization
            frmAmortization frmAmortization = new frmAmortization();
            frmAmortization.Show();
            // hide frmMortSchedule
            this.Hide();
        }
        private void AddToList()
        {
            // create the list dictionary and add loan details into the dictionary to make it easier to get data in JSON format
            var data = new List<Dictionary<string, string>>();
            // for loop to go through the items in the listbox and add into list loanDetails
            for (int i = 0; i < lbLoanStats.Items.Count; i++) {
                loanDetails.Add(lbLoanStats.Items[i].ToString());
                // creating individual dictionary items to record
                var item = new Dictionary<string, string>
                {
                    {"Loan Details", loanDetails[i]}
                };
                // adding item to dictionary
                data.Add(item);
            }
            // convert ther data into json format, including indentation to make it easier to read through the json filie
            string json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
            // write the json data to a json file
            File.WriteAllText("loanDetails.json", json);
        }
        private void btnExport_Click(object sender, EventArgs e)
        {
            // calling on the AddToList function to create dictionary, update loanDetails list, convert data into json file and write into json file.
            AddToList();
        }
    }
}
