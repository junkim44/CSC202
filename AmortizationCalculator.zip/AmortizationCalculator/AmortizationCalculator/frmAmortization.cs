using System.Numerics;

namespace AmortizationCalculator
{
    public partial class frmAmortization : Form
    {
        // Creating List to hold the amortization schedule
        List<string> amortSchedule = new List<string>();
        // I mainly created the global variables so that I can use them as constructors for the second form
        // since some of the details are restricted to a specific scope, I have it to update the global variables.
        // creating global double variable to keep track of the months it takes to pay the loan off
        int monthsToPay;
        // Using simple array to keep track of what the user inputs
        string[] userInput = new string[5];
        public frmAmortization()
        {
            InitializeComponent();
        }
        // constructor to switch to other form
        public frmAmortization(frmMortSchedule frmMortScheduleObj)
        {
            InitializeComponent();
        }
        // function to show message or exceptions
        private void ShowMessage(string message)
        {
            lblException.Text = message;
        }
        // function to check if the inputs are number and sanitize
        private bool CheckNumbers(out double principal, out double interest, out int termYear, out double extraPayment)
        {
            // clear previous message on lblException
            lblException.Text = "";
            // initializing variables
            principal = 0;
            interest = 0;
            termYear = 0;
            extraPayment = 0;
            // Check to see if the values entered for principal, interest, and term are numerical and also have a value in them
            // Those three are required fields to be filled out by the user.
            if (!double.TryParse(txtPrincipal.Text, out principal))
            {
                ShowMessage("Error: Please enter a numerical value for Mortgage Principal");
                return false;
            }
            if (!double.TryParse(txtInterest.Text, out interest))
            {
                ShowMessage("Error: Please enter a numerical value for Mortgage Interest");
                return false;
            }
            if (!int.TryParse(txtTermYear.Text, out termYear))
            {
                ShowMessage("Error: Please enter a numerical value for Mortgage Term");
                return false;
            }
            // Extra payment is optional, if the user does not input anything, the value of extra payment will default to 0
            string extraPayText = txtExtraPay.Text.Trim();
            if (extraPayText == "")
            {
                extraPayment = 0;
            }
            else if (!double.TryParse(txtExtraPay.Text, out extraPayment))
            {
                ShowMessage("Error: Please enter a numerical value for Extra Monthly Payment ");
                return false;
            }
            return true;
        }
        private void btnCalcMort_Click(object sender, EventArgs e)
        {
            // calling on the function CheckNumbers to convert the string to double
            if (CheckNumbers(out double principal, out double interest, out int termYear, out double extraPayment))
            {
                // initialize variables for calculation
                double monthlyInterest = (interest / 100) / 12;
                int termMonth = termYear * 12; // adding this variable for the sake of better UX for when the user compares terms, they won't have to calculate year to month
                string strTermMonth = termMonth.ToString();
                double mortExPay = extraPayment;
                double monthlyPay = 0;
                double totalPaid = 0;
                double totalInterest = 0;

                // must validate the values of principal, numberPayment, monthlyInterest, and extra payment to make sure the values aren't negative or necessary values aren't zero
                try
                {
                    if (principal > 0 && termMonth > 0 && monthlyInterest >= 0 && extraPayment >= 0)
                    {
                        // if interest rate is 0, the calculation will be different
                        if (monthlyInterest == 0)
                        {
                            monthlyPay = principal / termMonth;
                        }
                        else
                        {
                            // creating variable factor for exponential, so that I don't have to repeat Math.Pow
                            double factor = Math.Pow((1 + monthlyInterest), termMonth);
                            monthlyPay = principal * (monthlyInterest * factor) / (factor - 1);
                            // Stats I want to generate besides schedule
                            // Monthly payment, total payment to interest and total paid into the loan
                            // The format of the string list should be: month: # || Principal payment: $ || interest payment: $ for schedule listbox
                            // While loop to create the amortization schedule, first declaring variables for while loop
                            double balance = principal;
                            // while loop for amortization schedule
                            while (balance > 0)
                            {
                                // each time the loop is ran, add one to month
                                monthsToPay++;
                                // Calculate interest payment
                                double interestPay = balance * monthlyInterest;
                                double principalPay = monthlyPay - interestPay;

                                // If the user inputs extra payment per month, 
                                principalPay += extraPayment;

                                // logic for final payment, making sure that the payment doesn't go above the balance
                                if (principalPay > balance)
                                {
                                    principalPay = balance;
                                }
                                // Calculating payment for this month to use for totalPaid
                                double payThisMonth = interestPay + principalPay;
                                // Updating principal balance
                                balance -= principalPay;
                                // Updating total interest payment and total paid
                                totalInterest += interestPay;
                                totalPaid += payThisMonth;
                                // converting the calculations to string to add to my List
                                string scheduleString = $"Month: {monthsToPay} || Payment to Principal: ${Math.Round(principalPay, 2)} || Payment to Interest: ${Math.Round(interestPay)}";
                                // Adding scheduleString to List amortSchedule
                                amortSchedule.Add(scheduleString);
                            }
                        }
                    }
                    else
                    {
                        // exception messages for each of the validations, that way the user will have better idea of why the error message is showing up.
                        if (principal < 0) { throw new ArgumentOutOfRangeException("Error: The principal must be above 0"); }
                        if (termYear < 0) { throw new ArgumentOutOfRangeException("Error: The term must be above 0"); }
                        if (monthlyInterest < 0) { throw new ArgumentOutOfRangeException("Error: The interest rate cannot be below 0"); }
                        if (extraPayment < 0) { throw new ArgumentOutOfRangeException("Error: Extra payment cannot be below 0"); }
                    }
                    // Save user input to an array to give user an option to pull up their last input
                    userInput[0] = txtPrincipal.Text;
                    userInput[1] = txtTermYear.Text;
                    userInput[2] = strTermMonth;
                    userInput[3] = txtInterest.Text;
                    userInput[4] = txtExtraPay.Text;
                    // Write the user inputs to a text file in case the user wants to load the last mortgage info
                    File.WriteAllLines("mortgageInput.txt", userInput);
                    // if the logic doesn't hit any exceptions or issues, open up frmMortSchedule to show results
                    frmMortSchedule frmMortSchedule = new frmMortSchedule(amortSchedule, principal, monthsToPay, interest, monthlyPay, totalPaid, totalInterest, userInput);

                    // hide the current form
                    this.Hide();

                    // open up the frmMortSchedule
                    frmMortSchedule.Show();
                }
                // catch exceptions if thrown
                catch (Exception ex)
                {
                    ShowMessage(ex.Message);
                }
            }
        }
        // Function to load previous inquiry
        private void LoadPrevious()
        {
            // Get data from mortgageInput.txt and load it into the textbox, but also make sure that the file exists first.
            try
            {
                if (File.Exists("mortgageInput.txt"))
                {
                    // Creating array to hold all of the lines from mortgageIput.txt
                    string[] fileInput = File.ReadAllLines("mortgageInput.txt");
                    txtPrincipal.Text = fileInput[0];
                    txtTermYear.Text = fileInput[1];
                    txtInterest.Text = fileInput[3];
                    txtExtraPay.Text = fileInput[4];
                }
                else
                {
                    // if file not found, throw exception
                    throw new FileNotFoundException("Error: File not found");
                }
            }
            // catch exception and send message into lblException
            catch (Exception ex)
            {
                ShowMessage(ex.Message);
            }
        }
        private void btnLoad_Click(object sender, EventArgs e)
        {
            LoadPrevious();
        }
    }
}
