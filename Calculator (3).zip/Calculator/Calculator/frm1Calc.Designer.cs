﻿namespace Calculator
{
    partial class frm1Calc
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAdd = new Button();
            btnSubtract = new Button();
            btnMultiply = new Button();
            btnDivide = new Button();
            txtNum2 = new TextBox();
            txtNum1 = new TextBox();
            pictureBox1 = new PictureBox();
            lblTitle = new Label();
            lblResult = new Label();
            lblMessage = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btnAdd
            // 
            btnAdd.AutoSize = true;
            btnAdd.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAdd.Location = new Point(1076, 366);
            btnAdd.Margin = new Padding(7, 8, 7, 8);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(70, 75);
            btnAdd.TabIndex = 0;
            btnAdd.Text = "+";
            btnAdd.TextAlign = ContentAlignment.TopCenter;
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnSubtract
            // 
            btnSubtract.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnSubtract.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSubtract.Location = new Point(1076, 456);
            btnSubtract.Margin = new Padding(7, 8, 7, 8);
            btnSubtract.Name = "btnSubtract";
            btnSubtract.Size = new Size(70, 69);
            btnSubtract.TabIndex = 1;
            btnSubtract.Text = "-";
            btnSubtract.UseVisualStyleBackColor = true;
            btnSubtract.Click += btnSubtract_Click;
            // 
            // btnMultiply
            // 
            btnMultiply.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMultiply.Location = new Point(1076, 541);
            btnMultiply.Margin = new Padding(7, 8, 7, 8);
            btnMultiply.Name = "btnMultiply";
            btnMultiply.Size = new Size(70, 76);
            btnMultiply.TabIndex = 2;
            btnMultiply.Text = "*";
            btnMultiply.UseVisualStyleBackColor = true;
            btnMultiply.Click += btnMultiply_Click;
            // 
            // btnDivide
            // 
            btnDivide.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDivide.Location = new Point(1076, 633);
            btnDivide.Margin = new Padding(7, 8, 7, 8);
            btnDivide.Name = "btnDivide";
            btnDivide.Size = new Size(70, 76);
            btnDivide.TabIndex = 3;
            btnDivide.Text = "/";
            btnDivide.UseVisualStyleBackColor = true;
            btnDivide.Click += btnDivide_Click;
            // 
            // txtNum2
            // 
            txtNum2.Location = new Point(794, 541);
            txtNum2.Margin = new Padding(7, 8, 7, 8);
            txtNum2.Name = "txtNum2";
            txtNum2.Size = new Size(237, 47);
            txtNum2.TabIndex = 4;
            // 
            // txtNum1
            // 
            txtNum1.Location = new Point(794, 456);
            txtNum1.Margin = new Padding(7, 8, 7, 8);
            txtNum1.Name = "txtNum1";
            txtNum1.Size = new Size(237, 47);
            txtNum1.TabIndex = 5;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.ControlDark;
            pictureBox1.Location = new Point(748, 249);
            pictureBox1.Margin = new Padding(7, 8, 7, 8);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(437, 618);
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitle.Location = new Point(818, 273);
            lblTitle.Margin = new Padding(7, 0, 7, 0);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(300, 54);
            lblTitle.TabIndex = 7;
            lblTitle.Text = "UAT Calculator";
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.Font = new Font("Segoe UI", 12F);
            lblResult.Location = new Point(794, 779);
            lblResult.Margin = new Padding(7, 0, 7, 0);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(155, 54);
            lblResult.TabIndex = 8;
            lblResult.Text = "[Result]";
            // 
            // lblMessage
            // 
            lblMessage.AutoSize = true;
            lblMessage.Font = new Font("Segoe UI", 12F);
            lblMessage.Location = new Point(794, 366);
            lblMessage.Margin = new Padding(7, 0, 7, 0);
            lblMessage.Name = "lblMessage";
            lblMessage.Size = new Size(203, 54);
            lblMessage.TabIndex = 9;
            lblMessage.Text = "[Message]";
            // 
            // frm1Calc
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ClientSize = new Size(1943, 1230);
            Controls.Add(lblMessage);
            Controls.Add(lblResult);
            Controls.Add(lblTitle);
            Controls.Add(txtNum1);
            Controls.Add(txtNum2);
            Controls.Add(btnDivide);
            Controls.Add(btnMultiply);
            Controls.Add(btnSubtract);
            Controls.Add(btnAdd);
            Controls.Add(pictureBox1);
            Margin = new Padding(7, 8, 7, 8);
            Name = "frm1Calc";
            Text = "Calculator App";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAdd;
        private Button btnSubtract;
        private Button btnMultiply;
        private Button btnDivide;
        private TextBox txtNum2;
        private TextBox txtNum1;
        private PictureBox pictureBox1;
        private Label lblTitle;
        private Label lblResult;
        private Label lblMessage;
    }
}
