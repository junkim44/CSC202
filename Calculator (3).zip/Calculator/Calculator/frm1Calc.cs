using System.CodeDom;

namespace Calculator
{
    public partial class frm1Calc : Form
    {
        public frm1Calc()
        {
            InitializeComponent();
        }
        // Accessor value - private - this function/method can only be used in the current class (file)
        // The next value is return type - if no value is going to be returned, use void
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Converting string value to double, if txtNum1 or txtNum2 is not numerical, return error message.
            if (!CheckNumber(txtNum1, out double dNum1)) return;
            if (!CheckNumber(txtNum2, out double dNum2)) return;
            // Calling Calculate function for add
            Calculate(dNum1, dNum2, "Add");
            //}
        }
        // Event handler for subtracting numbers
        // If the issue is not very visible, click on the lightning button in properties, which will help you figure out which button it's set to
        private void btnSubtract_Click(object sender, EventArgs e)
        {
            // Converting string value to double
            // Converting string value to double, if txtNum1 or txtNum2 is not numerical, return error message.
            if (!CheckNumber(txtNum1, out double dNum1)) return;
            if (!CheckNumber(txtNum2, out double dNum2)) return;
            // Function to subtract two doubles together
            Calculate(dNum1, dNum2, "Subtract");
        }
        private void btnDivide_Click(object sender, EventArgs e)
        {
            // Converting string value to double, if txtNum1 or txtNum2 is not numerical, return error message.
            if (!CheckNumber(txtNum1, out double dNum1)) return;
            if (!CheckNumber(txtNum2, out double dNum2)) return;
            // if statement for division, if dNum2 is zero, error
            Calculate(dNum1, dNum2, "Divide");
        }
        private void btnMultiply_Click(object sender, EventArgs e)
        {
            // Converting string value to double, if txtNum1 or txtNum2 is not numerical, return error message.
            if (!CheckNumber(txtNum1, out double dNum1)) return;
            if (!CheckNumber(txtNum2, out double dNum2)) return;
            Calculate(dNum1, dNum2, "Multiply");
        }
     
        // Function to check if the input is number and sanitize
        private bool CheckNumber(TextBox txt, out double num)
        {
            // if you can convert the number, return true and output double num
            if (double.TryParse(txt.Text, out num)) {
                return true;
            }
            else
            {
                // if not number, return false and output error message.
                ShowMessage("Error: enter numerical value");
                return false;
            }
        }
        // Function to do all the calculation
        private void Calculate(double number1, double number2, string operation)
        {
            ShowMessage("");
            ShowResult("");
            // variable to hold the result of the calculation
            double result =0;
            // using switch logic to choose which function to do
            switch(operation)
            {
                case "Add":
                    result = number1 + number2;
                    break;
                case "Subtract":
                    result = number1 - number2;
                    break;
                case "Multiply":
                    result = number1 * number2;
                    break;
                case "Divide":
                    if (number2 == 0)
                    {
                        ShowMessage("Cannot Divide by 0, please try again");
                    }
                    else
                    {
                        result = number1 / number2;
                    }
                    break;
                // default case - if the operation was not in the list of options, this case will run
                default:
                    ShowMessage("Invalid operation, please try again");
                    break;
            }
            ShowResult($"Result: {result}");
        }
        // Function to show the message(s)
        private void ShowMessage(string message)
        {
            lblMessage.Text = message;
        }
        // Function to show result
        private void ShowResult(string result)
        {
            lblResult.Text = result;
        }
    }
}
