namespace Calculator
{
    public partial class frm1Calc : Form
    {
        public frm1Calc()
        {
            InitializeComponent();
        }
        // Accessor value - private - this function/method can only be used in the current class (file)
        // The next value is return type - if no value is going to be returned, use void
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Converting string value to double, if txtNum1 or txtNum2 is not numerical, return error message.
            if (!double.TryParse(txtNum1.Text, out double dNum1) || !double.TryParse(txtNum2.Text, out double dNum2)) {
                lblResult.Text = "Error: Enter a valid number";
            } else
            {
                // Function to add two doubles together
                double dSum = dNum1 + dNum2;
                lblResult.Text = $"Result: {dSum}"; // $ allows multiple data types to be outputted as string
            }
        }
        // Event handler for subtracting numbers
        // If the issue is not very visible, click on the lightning button in properties, which will help you figure out which button it's set to
        private void btnSubtract_Click(object sender, EventArgs e)
        {
            // Converting string value to double
            if (!double.TryParse(txtNum1.Text, out double dNum1) || !double.TryParse(txtNum2.Text, out double dNum2))
            {
                lblResult.Text = "Error: Enter a valid number";
            }
            else
            {
                // Function to subtract two doubles together
                double dSub = dNum1 - dNum2;
                lblResult.Text = $"Result: {dSub}"; 
            }
        }
        private void btnDivide_Click(object sender, EventArgs e)
        {
            // Converting string value to double
            if (!double.TryParse(txtNum1.Text, out double dNum1) || !double.TryParse(txtNum2.Text, out double dNum2))
            {
                lblResult.Text = "Error: Enter a valid number";
            }
            else
            {
                // if statement for division, if dNum2 is zero, error
                if (dNum2 == 0)
                {
                    lblResult.Text = "Error: Cannot divide by 0";
                }
                else
                {
                    double dDiv = dNum1 / dNum2;
                    lblResult.Text = $"Result: {dDiv}";
                }
            }
        }
        private void btnMultiply_Click(object sender, EventArgs e)
        {
            // Converting string value to double
            if (!double.TryParse(txtNum1.Text, out double dNum1) || !double.TryParse(txtNum2.Text, out double dNum2))
            {
                lblResult.Text = "Error: Enter a valid number";
            }
            else
            {
                // Function to multiply two doubles together
                double dMult = dNum1 * dNum2;
                lblResult.Text = $"Result: {dMult}";
            }
        }
    }
}
