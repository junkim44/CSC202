﻿namespace Calculator
{
    partial class frm1Calc
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAdd = new Button();
            btnSubtract = new Button();
            btnMultiply = new Button();
            btnDivide = new Button();
            txtNum2 = new TextBox();
            txtNum1 = new TextBox();
            pictureBox1 = new PictureBox();
            lblTitle = new Label();
            lblResult = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btnAdd
            // 
            btnAdd.AutoSize = true;
            btnAdd.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnAdd.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAdd.Location = new Point(443, 132);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(29, 30);
            btnAdd.TabIndex = 0;
            btnAdd.Text = "+";
            btnAdd.TextAlign = ContentAlignment.TopCenter;
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnSubtract
            // 
            btnSubtract.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnSubtract.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSubtract.Location = new Point(443, 168);
            btnSubtract.Name = "btnSubtract";
            btnSubtract.Size = new Size(29, 30);
            btnSubtract.TabIndex = 1;
            btnSubtract.Text = "-";
            btnSubtract.UseVisualStyleBackColor = true;
            btnSubtract.Click += btnSubtract_Click;
            // 
            // btnMultiply
            // 
            btnMultiply.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMultiply.Location = new Point(443, 204);
            btnMultiply.Name = "btnMultiply";
            btnMultiply.Size = new Size(29, 30);
            btnMultiply.TabIndex = 2;
            btnMultiply.Text = "*";
            btnMultiply.UseVisualStyleBackColor = true;
            btnMultiply.Click += btnMultiply_Click;
            // 
            // btnDivide
            // 
            btnDivide.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDivide.Location = new Point(443, 240);
            btnDivide.Name = "btnDivide";
            btnDivide.Size = new Size(29, 30);
            btnDivide.TabIndex = 3;
            btnDivide.Text = "/";
            btnDivide.UseVisualStyleBackColor = true;
            btnDivide.Click += btnDivide_Click;
            // 
            // txtNum2
            // 
            txtNum2.Location = new Point(327, 175);
            txtNum2.Name = "txtNum2";
            txtNum2.Size = new Size(100, 23);
            txtNum2.TabIndex = 4;
            // 
            // txtNum1
            // 
            txtNum1.Location = new Point(327, 137);
            txtNum1.Name = "txtNum1";
            txtNum1.Size = new Size(100, 23);
            txtNum1.TabIndex = 5;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.ControlDark;
            pictureBox1.Location = new Point(308, 91);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(180, 226);
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitle.Location = new Point(337, 100);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(123, 21);
            lblTitle.TabIndex = 7;
            lblTitle.Text = "UAT Calculator";
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.Font = new Font("Segoe UI", 12F);
            lblResult.Location = new Point(327, 285);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(63, 21);
            lblResult.TabIndex = 8;
            lblResult.Text = "[Result]";
            // 
            // frm1Calc
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblResult);
            Controls.Add(lblTitle);
            Controls.Add(txtNum1);
            Controls.Add(txtNum2);
            Controls.Add(btnDivide);
            Controls.Add(btnMultiply);
            Controls.Add(btnSubtract);
            Controls.Add(btnAdd);
            Controls.Add(pictureBox1);
            Name = "frm1Calc";
            Text = "Calculator App";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAdd;
        private Button btnSubtract;
        private Button btnMultiply;
        private Button btnDivide;
        private TextBox txtNum2;
        private TextBox txtNum1;
        private PictureBox pictureBox1;
        private Label lblTitle;
        private Label lblResult;
    }
}
