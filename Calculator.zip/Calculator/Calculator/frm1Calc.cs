namespace Calculator
{
    public partial class frm1Calc : Form
    {
        public frm1Calc()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
