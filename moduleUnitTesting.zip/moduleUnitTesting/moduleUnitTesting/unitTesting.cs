using System.Diagnostics;
namespace moduleUnitTesting
{
    public partial class unitTesting : Form
    {
        public unitTesting()
        {
            InitializeComponent();
        }
        //function to test the length of user input
        private bool lengthTest(string userInput)
        {
            if (userInput.Length == 0)
            {
                return false;
            } else
            {
                return true;
            }
        }
        // function to see if the value entered will be able to parse to int
        private bool validateInt(string userInput)
        {
            if (int.TryParse(userInput, out int result)) {
                return true;
            } else
            {
                return false;
            }
        }
        private void btnRunAssert_Click(object sender, EventArgs e)
        {
            // Creating two variables to hold gamerTag and level
            string gamerTag = txtGamerTag.Text;
            string level = txtLevel.Text;

            // using Debug.Assert with the condition that if the user did not enter anything for gamerTag, assert will trigger
            Debug.Assert(lengthTest(gamerTag), "Gamer tag cannot be empty");
            // using Debug.Assert with the condition that if the user did not enter anything for level, assert will trigger
            Debug.Assert(lengthTest(level), "Level cannot be empty");
            // using Debug.Assert to see if the user inputted integer value for level
            Debug.Assert(validateInt(level), "Please enter integer value for level");

        }
    }
}
