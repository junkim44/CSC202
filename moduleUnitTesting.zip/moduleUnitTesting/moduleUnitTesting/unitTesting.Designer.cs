﻿namespace moduleUnitTesting
{
    partial class unitTesting
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtGamerTag = new TextBox();
            txtLevel = new TextBox();
            lblGamerTag = new Label();
            lblLevel = new Label();
            btnRunAssert = new Button();
            SuspendLayout();
            // 
            // txtGamerTag
            // 
            txtGamerTag.Location = new Point(300, 144);
            txtGamerTag.Name = "txtGamerTag";
            txtGamerTag.Size = new Size(202, 23);
            txtGamerTag.TabIndex = 0;
            // 
            // txtLevel
            // 
            txtLevel.Location = new Point(300, 206);
            txtLevel.Name = "txtLevel";
            txtLevel.Size = new Size(202, 23);
            txtLevel.TabIndex = 1;
            // 
            // lblGamerTag
            // 
            lblGamerTag.AutoSize = true;
            lblGamerTag.Location = new Point(230, 147);
            lblGamerTag.Name = "lblGamerTag";
            lblGamerTag.Size = new Size(64, 15);
            lblGamerTag.TabIndex = 2;
            lblGamerTag.Text = "Gamer Tag";
            // 
            // lblLevel
            // 
            lblLevel.AutoSize = true;
            lblLevel.Location = new Point(230, 209);
            lblLevel.Name = "lblLevel";
            lblLevel.Size = new Size(34, 15);
            lblLevel.TabIndex = 3;
            lblLevel.Text = "Level";
            // 
            // btnRunAssert
            // 
            btnRunAssert.Location = new Point(395, 252);
            btnRunAssert.Name = "btnRunAssert";
            btnRunAssert.Size = new Size(107, 34);
            btnRunAssert.TabIndex = 4;
            btnRunAssert.Text = "Run Test";
            btnRunAssert.UseVisualStyleBackColor = true;
            btnRunAssert.Click += btnRunAssert_Click;
            // 
            // unitTesting
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnRunAssert);
            Controls.Add(lblLevel);
            Controls.Add(lblGamerTag);
            Controls.Add(txtLevel);
            Controls.Add(txtGamerTag);
            Name = "unitTesting";
            Text = "Unit Testing";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtGamerTag;
        private TextBox txtLevel;
        private Label lblGamerTag;
        private Label lblLevel;
        private Button btnRunAssert;
    }
}
