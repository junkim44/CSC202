using System.CodeDom;

namespace Project_Tracker
{
    public partial class frmDashboard : Form
    {
        // Creating Array of 10 elements for tasks
        string[] arrTaskDescription = new string[10];
        // Creating Array of 10 elements for the due dates 
        string[] arrTaskDueDate = new string[10];
        // Creating counter variable to keep track of array size
        int taskCounter = 0;
        public frmDashboard()
        {
            InitializeComponent();
        }
        // btnAddTask will be used to add the tasks in only with the task description and properly data format is used.
        private void btnAddTask_Click(object sender, EventArgs e)
        {
            // exception handling for when the user is trying to input more than 10 array elements
            try
            {
                if (taskCounter < 10)
                {
                    // task counter is also used as an index for arrays, so the text that's in the textbox when add task is clicked
                    // will be stored in the same index number for both array
                    arrTaskDescription[taskCounter] = txtTaskInput.Text;
                    arrTaskDueDate[taskCounter] = txtDateInput.Text;

                    // Clear the textbox for next entry.
                    txtTaskInput.Clear();
                    txtDateInput.Clear();

                    // display the tasks in label box and doing a separate one so that the due date will be below the task for better UX
                    lbTasks.Items.Add($"{taskCounter + 1}. {arrTaskDescription[taskCounter]}");
                    lbTasks.Items.Add($"Due Date: {arrTaskDueDate[taskCounter]}");

                    // each time a task is added, add one to task counter
                    taskCounter++;

                    // After a task has been entered, the btnCompTask will become available
                    btnCompTask.Enabled = true;
                }
                else
                {
                    // if array elements are full, throw index out of range exception
                    throw new IndexOutOfRangeException("UAT Task Tracker can only hold 10 tasks at a time, please complete a task before adding another.");
                }
            }
            catch (Exception ex)
            {
                // catches and prints error message to lblexception
                lblExceptions.Text = ex.Message;
            }
        }
        private void btnCompTask_Click(object sender, EventArgs e)
        {
            try
            {
                if (int.TryParse(txtTaskIndex.Text, out int displayIndex))
                {
                    // making another int variable to keep track of the array index for deleting the element from array
                    int arrayIndex = displayIndex - 1;

                    // arrayIndex has to be above 0 and below the taskCounter value for it to be valid
                    if (arrayIndex >= 0 && arrayIndex < taskCounter)
                    {
                        // for loop for shifting the array elements to fill the hole
                        for (int i = arrayIndex; i < taskCounter - 1; i++)
                        {
                            // Move the array elements up 1 number when a task is completed
                            arrTaskDescription[i] = arrTaskDescription[i + 1];
                            arrTaskDueDate[i] = arrTaskDueDate[i + 1];
                        }
                        // To clear the duplicate created at the end now and decrement counter since a task has been removed
                        taskCounter--;
                        // Because the loop has shifted everything forward, the last element in the array will be a duplicate, so set that duplicate element to null
                        arrTaskDescription[taskCounter] = null;
                        arrTaskDueDate[taskCounter] = null;

                        // Reset the lbTasks and show updated list and also clear the txtTaskIndex
                        ResetlbTasks();
                        txtTaskIndex.Clear();
                    }
                    else
                    {
                        // throw out of range exception if the value entered outside of the elements in array
                        throw new IndexOutOfRangeException("Task index was outside the bounds of the array, please enter the correct index number");
                    }
                }
                else
                {
                    // throw format exception if the value entered is not numerical
                    throw new FormatException("Please enter a numerical value.");
                }
            }
            catch (Exception ex)
            {
                // show exceptions message on lblExceptions.Text
                lblExceptions.Text = ex.Message;
            }
            // if my arrays are empty, disable the complete task button, it will get re-enabled when a task has been added
            if (taskCounter == 0)
            {
                btnCompTask.Enabled = false;
            }
         
        }
        // method to reset lbTasks after the task has been completed and the array element is now deleted
        private void ResetlbTasks()
        {
            // Clear the lbTasks first
            lbTasks.Items.Clear();
            // for loop to display the remaining tasks list
            for (int i = 0; i < taskCounter; i++)
            {
                lbTasks.Items.Add($"{i + 1}. {arrTaskDescription[i]}");
                lbTasks.Items.Add($"Due Date: {arrTaskDueDate[i]}");
            }
        }
    }
}
