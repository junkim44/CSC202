﻿namespace Project_Tracker
{
    partial class frmDashboard
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblWelcome = new Label();
            lbTasks = new ListBox();
            btnAddTask = new Button();
            btnCompTask = new Button();
            txtTaskInput = new TextBox();
            txtDateInput = new TextBox();
            lblTaskInputTitle = new Label();
            lblDueDateTitle = new Label();
            lblExceptions = new Label();
            lblCompleteTaskInst = new Label();
            txtTaskIndex = new TextBox();
            lblTaskIndex = new Label();
            SuspendLayout();
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.Font = new Font("Segoe UI", 20F);
            lblWelcome.ImageAlign = ContentAlignment.TopLeft;
            lblWelcome.Location = new Point(82, 38);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(314, 54);
            lblWelcome.TabIndex = 0;
            lblWelcome.Text = "UAT Task Tracker";
            // 
            // lbTasks
            // 
            lbTasks.Font = new Font("Segoe UI", 11F);
            lbTasks.FormattingEnabled = true;
            lbTasks.Location = new Point(89, 226);
            lbTasks.Name = "lbTasks";
            lbTasks.Size = new Size(1047, 484);
            lbTasks.TabIndex = 2;
            // 
            // btnAddTask
            // 
            btnAddTask.Font = new Font("Segoe UI", 12F);
            btnAddTask.Location = new Point(1171, 115);
            btnAddTask.Name = "btnAddTask";
            btnAddTask.Size = new Size(350, 49);
            btnAddTask.TabIndex = 3;
            btnAddTask.Text = "Add Task";
            btnAddTask.UseVisualStyleBackColor = true;
            btnAddTask.Click += btnAddTask_Click;
            // 
            // btnCompTask
            // 
            btnCompTask.Enabled = false;
            btnCompTask.Font = new Font("Segoe UI", 12F);
            btnCompTask.Location = new Point(1171, 775);
            btnCompTask.Name = "btnCompTask";
            btnCompTask.RightToLeft = RightToLeft.Yes;
            btnCompTask.Size = new Size(350, 49);
            btnCompTask.TabIndex = 4;
            btnCompTask.Text = "Complete Task";
            btnCompTask.UseVisualStyleBackColor = true;
            btnCompTask.Click += btnCompTask_Click;
            // 
            // txtTaskInput
            // 
            txtTaskInput.AcceptsTab = true;
            txtTaskInput.Location = new Point(234, 115);
            txtTaskInput.Name = "txtTaskInput";
            txtTaskInput.Size = new Size(902, 31);
            txtTaskInput.TabIndex = 6;
            // 
            // txtDateInput
            // 
            txtDateInput.Location = new Point(293, 179);
            txtDateInput.Name = "txtDateInput";
            txtDateInput.Size = new Size(843, 31);
            txtDateInput.TabIndex = 7;
            // 
            // lblTaskInputTitle
            // 
            lblTaskInputTitle.AutoSize = true;
            lblTaskInputTitle.Font = new Font("Segoe UI", 12F);
            lblTaskInputTitle.Location = new Point(89, 112);
            lblTaskInputTitle.Name = "lblTaskInputTitle";
            lblTaskInputTitle.Size = new Size(125, 32);
            lblTaskInputTitle.TabIndex = 8;
            lblTaskInputTitle.Text = "Enter Task:";
            // 
            // lblDueDateTitle
            // 
            lblDueDateTitle.AutoSize = true;
            lblDueDateTitle.Font = new Font("Segoe UI", 12F);
            lblDueDateTitle.Location = new Point(89, 179);
            lblDueDateTitle.Name = "lblDueDateTitle";
            lblDueDateTitle.Size = new Size(182, 32);
            lblDueDateTitle.TabIndex = 9;
            lblDueDateTitle.Text = "Enter Due Date:";
            // 
            // lblExceptions
            // 
            lblExceptions.AutoSize = true;
            lblExceptions.ForeColor = Color.FromArgb(192, 0, 0);
            lblExceptions.Location = new Point(89, 723);
            lblExceptions.Name = "lblExceptions";
            lblExceptions.Size = new Size(0, 25);
            lblExceptions.TabIndex = 10;
            // 
            // lblCompleteTaskInst
            // 
            lblCompleteTaskInst.AutoSize = true;
            lblCompleteTaskInst.Location = new Point(771, 765);
            lblCompleteTaskInst.Name = "lblCompleteTaskInst";
            lblCompleteTaskInst.Size = new Size(394, 25);
            lblCompleteTaskInst.TabIndex = 11;
            lblCompleteTaskInst.Text = "Enter the task index number to mark it complete";
            // 
            // txtTaskIndex
            // 
            txtTaskIndex.Location = new Point(874, 793);
            txtTaskIndex.Name = "txtTaskIndex";
            txtTaskIndex.Size = new Size(140, 31);
            txtTaskIndex.TabIndex = 12;
            // 
            // lblTaskIndex
            // 
            lblTaskIndex.AutoSize = true;
            lblTaskIndex.Location = new Point(771, 799);
            lblTaskIndex.Name = "lblTaskIndex";
            lblTaskIndex.Size = new Size(97, 25);
            lblTaskIndex.TabIndex = 13;
            lblTaskIndex.Text = "Task Index:";
            // 
            // frmDashboard
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1564, 861);
            Controls.Add(lblTaskIndex);
            Controls.Add(txtTaskIndex);
            Controls.Add(lblCompleteTaskInst);
            Controls.Add(lblExceptions);
            Controls.Add(lblDueDateTitle);
            Controls.Add(lblTaskInputTitle);
            Controls.Add(txtDateInput);
            Controls.Add(txtTaskInput);
            Controls.Add(btnCompTask);
            Controls.Add(btnAddTask);
            Controls.Add(lbTasks);
            Controls.Add(lblWelcome);
            Name = "frmDashboard";
            Text = "Dashboard";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblWelcome;
        private ListBox lbTasks;
        private Button btnAddTask;
        private Button btnCompTask;
        private TextBox txtTaskInput;
        private TextBox txtDateInput;
        private Label lblTaskInputTitle;
        private Label lblDueDateTitle;
        private Label lblExceptions;
        private Label lblCompleteTaskInst;
        private TextBox txtTaskIndex;
        private Label lblTaskIndex;
    }
}
