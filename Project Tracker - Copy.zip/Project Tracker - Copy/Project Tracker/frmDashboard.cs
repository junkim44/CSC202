using System.CodeDom;

namespace Project_Tracker
{
    public partial class frmDashboard : Form
    {
        // Creating Array of 10 elements for tasks
        string[] arrTaskDescription = new string[50];
        // Creating Array of 10 elements for the due dates 
        string[] arrTaskDueDate = new string[50];
        // Creating Array of 50 elements to hold completion status
        bool[] arrStatus = new bool[50];
        // Creating counter variable to keep track of array size
        int taskCounter = 0;
        public frmDashboard()
        {
            InitializeComponent();
        }
        // btnAddTask will be used to add the tasks in only with the task description and properly data format is used.
        private void btnAddTask_Click(object sender, EventArgs e)
        {
            // exception handling for when the user is trying to input more than 50 array elements
            try
            {
                if (taskCounter < 50 && txtTaskInput.Text != "" && txtDateInput.Text != "")
                {
                    // task counter is also used as an index for arrays, so the text that's in the textbox when add task is clicked
                    // will be stored in the same index number for both array
                    arrTaskDescription[taskCounter] = txtTaskInput.Text;
                    arrTaskDueDate[taskCounter] = txtDateInput.Text;
                    arrStatus[taskCounter] = false;

                    // Clear the textbox for next entry.
                    txtTaskInput.Clear();
                    txtDateInput.Clear();

                    // display the tasks in label box and doing a separate one so that the due date will be below the task for better UX
                    lbTasks.Items.Add($"{taskCounter + 1}. {arrTaskDescription[taskCounter]} || Due Date: {arrTaskDueDate[taskCounter]}" + " (Pending)");

                    // each time a task is added, add one to task counter
                    taskCounter++;

                    // After a task has been entered, the btnCompTask will become available
                    btnCompTask.Enabled = true;
                }
                else
                {
                    // if array elements are full, throw index out of range exception
                    throw new IndexOutOfRangeException("UAT Task Tracker can only hold 10 tasks at a time, please complete a task before adding another.");
                }
            }
            catch (Exception ex)
            {
                // catches and prints error message to lblexception
                lblExceptions.Text = ex.Message;
            }
        }
        private void btnCompTask_Click(object sender, EventArgs e)
        {
            // get the selected item from the listbox
            int iSelIndex = lbTasks.SelectedIndex;

            // this means that the user selected an item in the listbox before clicking complete
            if (iSelIndex >= 0)
            {
                // change the completed status to true
                arrStatus[iSelIndex] = true;

                // show updated task in the listbox with the updated status
                lbTasks.Items[iSelIndex] = ((taskCounter + 1) + ". " + (arrTaskDescription[iSelIndex]) + " || Due Date:" + (arrTaskDueDate[iSelIndex]) + " (Complete)");
            }

        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            // write the task and due dates to separate file
            File.WriteAllLines("tasks.txt", arrTaskDescription[..taskCounter]);
            File.WriteAllLines("dueDates.txt", arrTaskDueDate[..taskCounter]);
            // for bool value, to write to file, needs to be string
            string[] arrStatusString = new string[taskCounter];
            // using for loop to convert each of the bool to string
            for (int i = 0; i < taskCounter; i++)
            {
                if (arrStatus[i])
                {
                    arrStatusString[i] += "Complete";
                }
                else
                {
                    arrStatusString[i] += "Pending";
                }
            }
            // write out the statuses in string format to a different file
            File.WriteAllLines("status.txt", arrStatusString);
        }
        private void btnLoad_Click(object sender, EventArgs e)
        {
            // get data from our 3 files and load it in the listbox
            if (File.Exists("tasks.txt") && File.Exists("dueDates.txt") && File.Exists("status.txt"))
            {
                string[] fileTasks = File.ReadAllLines("tasks.txt");
                string[] fileDueDates = File.ReadAllLines("dueDates.txt");
                string[] fileStatus = File.ReadAllLines("status.txt");

                // get the number of tasks that were in the file
                int totalFileTasks = fileTasks.Length;

                // reset the array counter for the original arrays
                taskCounter = totalFileTasks;

                // clear out the listbox
                lbTasks.Items.Clear();

                // loop through the arrays and add items to the listbox
                for (int i = 0; i < totalFileTasks; i++)
                {
                    // update the array holding the tasks
                    arrTaskDescription[i] = fileTasks[i];
                    arrTaskDueDate[i] = fileDueDates[i];
                    // Check the status and add true or false to the status array
                    if (fileStatus[i] == "Pending")
                    {
                        arrStatus[i] = false;
                    } else
                    {
                        arrStatus[i] = true;
                    }
                    string task = (arrTaskDescription[i] + " || Due Date: " + arrTaskDueDate[i] + " (" + fileStatus[i] + ")");
                    // add the text to the listbox
                    lbTasks.Items.Add(task);
                }
            }
        }
    }
}
