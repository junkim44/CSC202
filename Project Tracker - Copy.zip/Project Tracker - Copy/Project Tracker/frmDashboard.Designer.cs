﻿namespace Project_Tracker
{
    partial class frmDashboard
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblWelcome = new Label();
            lbTasks = new ListBox();
            btnAddTask = new Button();
            btnCompTask = new Button();
            txtTaskInput = new TextBox();
            txtDateInput = new TextBox();
            lblTaskInputTitle = new Label();
            lblDueDateTitle = new Label();
            lblExceptions = new Label();
            btnSave = new Button();
            btnLoad = new Button();
            SuspendLayout();
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.Font = new Font("Segoe UI", 20F);
            lblWelcome.ImageAlign = ContentAlignment.TopLeft;
            lblWelcome.Location = new Point(57, 23);
            lblWelcome.Margin = new Padding(2, 0, 2, 0);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(210, 37);
            lblWelcome.TabIndex = 0;
            lblWelcome.Text = "UAT Task Tracker";
            // 
            // lbTasks
            // 
            lbTasks.Font = new Font("Segoe UI", 11F);
            lbTasks.FormattingEnabled = true;
            lbTasks.Location = new Point(62, 136);
            lbTasks.Margin = new Padding(2);
            lbTasks.Name = "lbTasks";
            lbTasks.Size = new Size(734, 364);
            lbTasks.TabIndex = 2;
            // 
            // btnAddTask
            // 
            btnAddTask.Font = new Font("Segoe UI", 12F);
            btnAddTask.Location = new Point(820, 69);
            btnAddTask.Margin = new Padding(2);
            btnAddTask.Name = "btnAddTask";
            btnAddTask.Size = new Size(245, 29);
            btnAddTask.TabIndex = 3;
            btnAddTask.Text = "Add Task";
            btnAddTask.UseVisualStyleBackColor = true;
            btnAddTask.Click += btnAddTask_Click;
            // 
            // btnCompTask
            // 
            btnCompTask.Enabled = false;
            btnCompTask.Font = new Font("Segoe UI", 12F);
            btnCompTask.Location = new Point(820, 107);
            btnCompTask.Margin = new Padding(2);
            btnCompTask.Name = "btnCompTask";
            btnCompTask.RightToLeft = RightToLeft.Yes;
            btnCompTask.Size = new Size(245, 29);
            btnCompTask.TabIndex = 4;
            btnCompTask.Text = "Complete Task";
            btnCompTask.UseVisualStyleBackColor = true;
            btnCompTask.Click += btnCompTask_Click;
            // 
            // txtTaskInput
            // 
            txtTaskInput.AcceptsTab = true;
            txtTaskInput.Location = new Point(164, 69);
            txtTaskInput.Margin = new Padding(2);
            txtTaskInput.Name = "txtTaskInput";
            txtTaskInput.Size = new Size(633, 23);
            txtTaskInput.TabIndex = 6;
            // 
            // txtDateInput
            // 
            txtDateInput.Location = new Point(205, 107);
            txtDateInput.Margin = new Padding(2);
            txtDateInput.Name = "txtDateInput";
            txtDateInput.Size = new Size(591, 23);
            txtDateInput.TabIndex = 7;
            // 
            // lblTaskInputTitle
            // 
            lblTaskInputTitle.AutoSize = true;
            lblTaskInputTitle.Font = new Font("Segoe UI", 12F);
            lblTaskInputTitle.Location = new Point(62, 67);
            lblTaskInputTitle.Margin = new Padding(2, 0, 2, 0);
            lblTaskInputTitle.Name = "lblTaskInputTitle";
            lblTaskInputTitle.Size = new Size(82, 21);
            lblTaskInputTitle.TabIndex = 8;
            lblTaskInputTitle.Text = "Enter Task:";
            // 
            // lblDueDateTitle
            // 
            lblDueDateTitle.AutoSize = true;
            lblDueDateTitle.Font = new Font("Segoe UI", 12F);
            lblDueDateTitle.Location = new Point(62, 107);
            lblDueDateTitle.Margin = new Padding(2, 0, 2, 0);
            lblDueDateTitle.Name = "lblDueDateTitle";
            lblDueDateTitle.Size = new Size(117, 21);
            lblDueDateTitle.TabIndex = 9;
            lblDueDateTitle.Text = "Enter Due Date:";
            // 
            // lblExceptions
            // 
            lblExceptions.AutoSize = true;
            lblExceptions.ForeColor = Color.FromArgb(192, 0, 0);
            lblExceptions.Location = new Point(62, 434);
            lblExceptions.Margin = new Padding(2, 0, 2, 0);
            lblExceptions.Name = "lblExceptions";
            lblExceptions.Size = new Size(0, 15);
            lblExceptions.TabIndex = 10;
            // 
            // btnSave
            // 
            btnSave.AutoSize = true;
            btnSave.Font = new Font("Segoe UI", 12F);
            btnSave.Location = new Point(840, 474);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(99, 31);
            btnSave.TabIndex = 14;
            btnSave.Text = "Save to File";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnLoad
            // 
            btnLoad.AutoSize = true;
            btnLoad.Font = new Font("Segoe UI", 12F);
            btnLoad.Location = new Point(945, 474);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(120, 31);
            btnLoad.TabIndex = 15;
            btnLoad.Text = "Load from File";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // frmDashboard
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1095, 517);
            Controls.Add(btnLoad);
            Controls.Add(btnSave);
            Controls.Add(lblExceptions);
            Controls.Add(lblDueDateTitle);
            Controls.Add(lblTaskInputTitle);
            Controls.Add(txtDateInput);
            Controls.Add(txtTaskInput);
            Controls.Add(btnCompTask);
            Controls.Add(btnAddTask);
            Controls.Add(lbTasks);
            Controls.Add(lblWelcome);
            Margin = new Padding(2);
            Name = "frmDashboard";
            Text = "Dashboard";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblWelcome;
        private ListBox lbTasks;
        private Button btnAddTask;
        private Button btnCompTask;
        private TextBox txtTaskInput;
        private TextBox txtDateInput;
        private Label lblTaskInputTitle;
        private Label lblDueDateTitle;
        private Label lblExceptions;
        private Button btnSave;
        private Button btnLoad;
    }
}
